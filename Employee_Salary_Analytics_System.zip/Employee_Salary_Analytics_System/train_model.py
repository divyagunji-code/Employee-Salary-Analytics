"""
Employee Salary Analytics System — Model Training Pipeline
Author : Divya
Date   : May 2026
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
import joblib
import os
import warnings
warnings.filterwarnings("ignore")

# ─── Paths ────────────────────────────────────────────────────────────────────
DATASET_PATH   = "employee_salary_dataset.xlsx"
MODEL_OUTPUT   = "salary_prediction_model.pkl"
ENCODER_OUTPUT = "salary_encoders.pkl"

# ─── Categorical columns that require encoding ─────────────────────────────────
CATEGORICAL_FIELDS = ["Education_Level", "Department", "Job_Title"]

# ─── Target column ─────────────────────────────────────────────────────────────
TARGET_COLUMN = "Salary"

# ─── Feature columns (drop Employee_ID and target) ────────────────────────────
FEATURE_COLUMNS = [
    "Experience_Years",
    "Education_Level",
    "Department",
    "Job_Title",
    "Age",
    "Working_Hours_Per_Week",
    "Performance_Score",
]


# ──────────────────────────────────────────────────────────────────────────────
def load_workforce_data(filepath: str) -> pd.DataFrame:
    """Load the employee Excel dataset and perform basic sanity checks."""
    print("\n📂  Loading workforce dataset …")
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset not found: {filepath}")
    workforce_df = pd.read_excel(filepath)
    print(f"    ✅  Loaded {len(workforce_df):,} employee records | "
          f"{workforce_df.shape[1]} columns")
    return workforce_df


def cleanse_records(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Handle missing values and outliers."""
    print("\n🔧  Cleansing records …")
    cleansed = raw_df.copy()

    numeric_cols = cleansed.select_dtypes(include=[np.number]).columns.tolist()
    string_cols  = cleansed.select_dtypes(include=["object"]).columns.tolist()

    missing_before = cleansed.isnull().sum().sum()
    for col in numeric_cols:
        cleansed[col] = cleansed[col].fillna(cleansed[col].median())
    for col in string_cols:
        if cleansed[col].isnull().any():
            cleansed[col] = cleansed[col].fillna(cleansed[col].mode()[0])

    missing_after = cleansed.isnull().sum().sum()
    print(f"    ✅  Missing values fixed: {missing_before} → {missing_after}")
    return cleansed


def encode_category_fields(
    workforce_df: pd.DataFrame,
    cat_fields: list,
) -> tuple[pd.DataFrame, dict]:
    """Label-encode categorical columns and return updated df + encoder map."""
    print("\n🔤  Encoding categorical fields …")
    encoder_registry: dict = {}
    encoded_df = workforce_df.copy()

    for field in cat_fields:
        le = LabelEncoder()
        encoded_df[field] = le.fit_transform(encoded_df[field].astype(str))
        encoder_registry[field] = le
        unique_vals = list(le.classes_)
        print(f"    ✅  {field}: {len(unique_vals)} categories → {unique_vals}")

    return encoded_df, encoder_registry


def partition_dataset(
    encoded_df: pd.DataFrame,
    features: list,
    target: str,
    holdout_ratio: float = 0.20,
    seed: int = 7,
) -> tuple:
    """Split the dataset into training and holdout sets."""
    print("\n✂️   Partitioning dataset …")
    feature_matrix = encoded_df[features]
    salary_vector  = encoded_df[target]

    X_train, X_holdout, y_train, y_holdout = train_test_split(
        feature_matrix, salary_vector,
        test_size=holdout_ratio,
        random_state=seed,
    )
    print(f"    ✅  Training samples  : {len(X_train):,}")
    print(f"    ✅  Holdout samples   : {len(X_holdout):,}")
    return X_train, X_holdout, y_train, y_holdout


def build_analytics_model(
    X_train: pd.DataFrame,
    y_train: pd.Series,
) -> RandomForestRegressor:
    """Train a RandomForestRegressor on the workforce data."""
    print("\n🌲  Training RandomForest Salary Analytics Model …")
    rf_model = RandomForestRegressor(
        n_estimators=250,
        max_depth=12,
        min_samples_split=4,
        min_samples_leaf=2,
        max_features="sqrt",
        n_jobs=-1,
        random_state=21,
    )
    rf_model.fit(X_train, y_train)
    print("    ✅  Model training complete")
    return rf_model


def assess_model_performance(
    trained_model: RandomForestRegressor,
    X_train: pd.DataFrame,
    X_holdout: pd.DataFrame,
    y_train: pd.Series,
    y_holdout: pd.Series,
) -> dict:
    """Evaluate the model and print a detailed performance report."""
    print("\n📊  Evaluating model performance …")

    train_preds   = trained_model.predict(X_train)
    holdout_preds = trained_model.predict(X_holdout)

    train_r2   = r2_score(y_train, train_preds)
    holdout_r2 = r2_score(y_holdout, holdout_preds)
    mae        = mean_absolute_error(y_holdout, holdout_preds)
    rmse       = np.sqrt(mean_squared_error(y_holdout, holdout_preds))
    accuracy_pct = holdout_r2 * 100

    # Cross-validation
    cv_scores = cross_val_score(trained_model, X_train, y_train, cv=5, scoring="r2")

    print("\n" + "═" * 55)
    print("       EMPLOYEE SALARY ANALYTICS — MODEL REPORT")
    print("═" * 55)
    print(f"  Training R²       : {train_r2:.4f}")
    print(f"  Holdout R²        : {holdout_r2:.4f}")
    print(f"  Model Accuracy    : {accuracy_pct:.2f} %")
    print(f"  MAE  (USD)        : ${mae:,.2f}")
    print(f"  RMSE (USD)        : ${rmse:,.2f}")
    print(f"  CV R² (5-fold)    : {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")

    # Feature importance
    importance_series = pd.Series(
        trained_model.feature_importances_,
        index=X_train.columns,
    ).sort_values(ascending=False)
    print("\n  Top Feature Importances:")
    for feat, score in importance_series.head(5).items():
        bar = "█" * int(score * 40)
        print(f"    {feat:<28} {bar}  {score:.3f}")
    print("═" * 55)

    return {
        "train_r2"   : train_r2,
        "holdout_r2" : holdout_r2,
        "accuracy"   : accuracy_pct,
        "mae"        : mae,
        "rmse"       : rmse,
    }


def persist_artifacts(
    trained_model: RandomForestRegressor,
    encoder_registry: dict,
    model_path: str,
    encoder_path: str,
) -> None:
    """Save the model and encoders to disk."""
    print(f"\n💾  Saving model → {model_path}")
    joblib.dump(trained_model, model_path)

    print(f"💾  Saving encoders → {encoder_path}")
    joblib.dump(encoder_registry, encoder_path)

    model_mb   = os.path.getsize(model_path)   / 1024 / 1024
    encoder_kb = os.path.getsize(encoder_path) / 1024
    print(f"    ✅  {model_path}   ({model_mb:.2f} MB)")
    print(f"    ✅  {encoder_path} ({encoder_kb:.1f} KB)")


# ──────────────────────────────────────────────────────────────────────────────
def run_training_pipeline() -> None:
    print("=" * 55)
    print("  EMPLOYEE SALARY ANALYTICS — TRAINING PIPELINE")
    print("=" * 55)

    # Step 1: Load
    workforce_df = load_workforce_data(DATASET_PATH)

    # Step 2: Cleanse
    clean_df = cleanse_records(workforce_df)

    # Step 3: Encode
    encoded_df, encoder_registry = encode_category_fields(
        clean_df, CATEGORICAL_FIELDS
    )

    # Step 4: Split
    X_train, X_holdout, y_train, y_holdout = partition_dataset(
        encoded_df, FEATURE_COLUMNS, TARGET_COLUMN
    )

    # Step 5: Train
    analytics_model = build_analytics_model(X_train, y_train)

    # Step 6: Evaluate
    metrics = assess_model_performance(
        analytics_model, X_train, X_holdout, y_train, y_holdout
    )

    # Step 7: Persist
    persist_artifacts(
        analytics_model, encoder_registry, MODEL_OUTPUT, ENCODER_OUTPUT
    )

    print("\n🎉  Training pipeline completed successfully!")
    print(f"    Model accuracy: {metrics['accuracy']:.2f}%")
    print(f"    Files ready for Streamlit app:")
    print(f"      → {MODEL_OUTPUT}")
    print(f"      → {ENCODER_OUTPUT}")
    print("=" * 55 + "\n")


if __name__ == "__main__":
    run_training_pipeline()
