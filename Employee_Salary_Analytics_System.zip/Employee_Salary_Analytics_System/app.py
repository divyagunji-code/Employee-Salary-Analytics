"""
Employee Salary Analytics Dashboard
Author : Divya
Date   : May 2026
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os

# ─── Page Configuration ────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Employee Salary Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Global font */
    html, body, [class*="css"] { font-family: 'Segoe UI', sans-serif; }

    /* Top metric cards */
    .metric-card {
        background: linear-gradient(135deg, #1e3a5f 0%, #2e75b6 100%);
        border-radius: 12px;
        padding: 18px 22px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        margin-bottom: 10px;
    }
    .metric-card h2 { margin: 0; font-size: 2rem; font-weight: 700; }
    .metric-card p  { margin: 4px 0 0; font-size: 0.85rem; opacity: 0.85; }

    /* Salary result box */
    .salary-result {
        background: linear-gradient(135deg, #0f5132 0%, #198754 100%);
        border-radius: 14px;
        padding: 28px;
        color: white;
        text-align: center;
        box-shadow: 0 6px 20px rgba(25, 135, 84, 0.35);
        margin: 18px 0;
    }
    .salary-result h1 { font-size: 3rem; margin: 0; font-weight: 800; }
    .salary-result p  { font-size: 1.1rem; margin: 6px 0 0; opacity: 0.9; }

    /* Income level badge */
    .badge-entry    { background:#cfe2ff; color:#084298;  border-radius:20px; padding:6px 18px; font-weight:600; }
    .badge-mid      { background:#d1e7dd; color:#0a3622;  border-radius:20px; padding:6px 18px; font-weight:600; }
    .badge-senior   { background:#fff3cd; color:#664d03;  border-radius:20px; padding:6px 18px; font-weight:600; }
    .badge-executive{ background:#f8d7da; color:#58151c;  border-radius:20px; padding:6px 18px; font-weight:600; }

    /* Section headings */
    .section-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: #1e3a5f;
        border-left: 4px solid #2e75b6;
        padding-left: 10px;
        margin: 20px 0 10px;
    }

    /* Footer */
    .footer {
        text-align: center;
        color: #6c757d;
        font-size: 0.8rem;
        padding: 20px 0 5px;
        border-top: 1px solid #dee2e6;
        margin-top: 30px;
    }

    /* Sidebar styling */
    [data-testid="stSidebar"] { background: linear-gradient(180deg, #1e3a5f 0%, #16213e 100%); }
    [data-testid="stSidebar"] * { color: #e8f4fd !important; }
    [data-testid="stSidebar"] h1,
    [data-testid="stSidebar"] h2,
    [data-testid="stSidebar"] h3 { color: #90caf9 !important; }

    /* Button styles */
    div[data-testid="column"] button { border-radius: 8px !important; font-weight: 600 !important; }
</style>
""", unsafe_allow_html=True)


# ─── Load Artifacts ────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner="Loading analytics model …")
def fetch_model_artifacts():
    try:
        analytics_model  = joblib.load("salary_prediction_model.pkl")
        label_encoders   = joblib.load("salary_encoders.pkl")
        return analytics_model, label_encoders
    except FileNotFoundError:
        return None, None


@st.cache_data(show_spinner="Loading dataset …")
def fetch_workforce_data():
    if os.path.exists("employee_salary_dataset.xlsx"):
        return pd.read_excel("employee_salary_dataset.xlsx")
    return None


analytics_model, label_encoders = fetch_model_artifacts()
workforce_df = fetch_workforce_data()

# ─── Guard: training required ──────────────────────────────────────────────────
if analytics_model is None:
    st.error(
        "⚠️  Model files not found. "
        "Please run `python train_model.py` to generate "
        "`salary_prediction_model.pkl` and `salary_encoders.pkl` first."
    )
    st.info("💡 **Quick start:** Open a terminal in this folder and run:\n```\npython train_model.py\n```")
    st.stop()


# ─── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 📊 Analytics Dashboard")
    st.markdown("---")
    st.markdown("### 🔍 About")
    st.markdown(
        "Predicts employee compensation using a "
        "**Random Forest** model trained on 280+ workforce records."
    )
    st.markdown("---")
    st.markdown("### 📌 Model Info")
    st.markdown("- Algorithm: Random Forest")
    st.markdown("- Features: 7 input variables")
    st.markdown("- Training data: 280 records")
    st.markdown("---")

    if workforce_df is not None:
        st.markdown("### 📈 Dataset Stats")
        st.metric("Total Employees", f"{len(workforce_df):,}")
        st.metric("Avg Salary (USD)", f"${workforce_df['Salary'].mean():,.0f}")
        st.metric("Max Salary (USD)", f"${workforce_df['Salary'].max():,.0f}")
        st.markdown("---")

    st.markdown("### 🎛️ Navigation")
    dashboard_view = st.radio(
        "Select view:",
        ["🔮 Salary Predictor", "📊 Employee Insights"],
        label_visibility="collapsed",
    )
    st.markdown("---")
    st.markdown(
        "<small>Built with Streamlit & Scikit-learn<br/>© 2026 Divya</small>",
        unsafe_allow_html=True,
    )


# ─── Header ───────────────────────────────────────────────────────────────────
st.markdown("# 📊 Employee Salary Analytics Dashboard")
st.markdown(
    "Use workforce data to predict compensation levels and analyse employee trends."
)

# ─── Top KPI Row (when dataset available) ─────────────────────────────────────
if workforce_df is not None:
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(
            f"""<div class="metric-card">
                <h2>{len(workforce_df):,}</h2>
                <p>Total Employees</p>
            </div>""", unsafe_allow_html=True
        )
    with k2:
        st.markdown(
            f"""<div class="metric-card">
                <h2>${workforce_df['Salary'].mean():,.0f}</h2>
                <p>Average Salary</p>
            </div>""", unsafe_allow_html=True
        )
    with k3:
        st.markdown(
            f"""<div class="metric-card">
                <h2>{workforce_df['Experience_Years'].mean():.1f} yrs</h2>
                <p>Avg Experience</p>
            </div>""", unsafe_allow_html=True
        )
    with k4:
        st.markdown(
            f"""<div class="metric-card">
                <h2>{workforce_df['Performance_Score'].mean():.1f}/5</h2>
                <p>Avg Performance</p>
            </div>""", unsafe_allow_html=True
        )
    st.markdown("<br>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
#  VIEW 1 — SALARY PREDICTOR
# ══════════════════════════════════════════════════════════════════════════════
if "🔮 Salary Predictor" in dashboard_view:

    st.markdown("---")
    st.markdown("## 🔮 Salary Prediction Engine")

    # Retrieve dropdown options from encoders
    edu_options   = list(label_encoders["Education_Level"].classes_)
    dept_options  = list(label_encoders["Department"].classes_)
    title_options = list(label_encoders["Job_Title"].classes_)

    # ── Input Form ────────────────────────────────────────────────────────────
    st.markdown('<div class="section-title">👤 Employee Profile</div>', unsafe_allow_html=True)

    col_a, col_b, col_c = st.columns(3)

    with col_a:
        input_experience = st.number_input(
            "💼 Experience Years",
            min_value=0.0, max_value=40.0, value=5.0, step=0.5,
            help="Total years of professional work experience"
        )
        input_age = st.number_input(
            "🎂 Age",
            min_value=18, max_value=65, value=28,
            help="Employee's current age"
        )
        input_education = st.selectbox(
            "🎓 Education Level",
            options=edu_options,
            help="Highest education qualification"
        )

    with col_b:
        input_department = st.selectbox(
            "🏢 Department",
            options=dept_options,
            help="Department the employee works in"
        )
        input_job_title = st.selectbox(
            "📋 Job Title",
            options=title_options,
            help="Employee's current job title"
        )

    with col_c:
        input_working_hours = st.slider(
            "⏰ Working Hours / Week",
            min_value=30, max_value=70, value=40,
            help="Average weekly working hours"
        )
        input_performance = st.slider(
            "⭐ Performance Score",
            min_value=1.0, max_value=5.0, value=3.5, step=0.1,
            help="Performance rating (1 = Low, 5 = Excellent)"
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Validation ────────────────────────────────────────────────────────────
    validation_errors = []
    if input_age < int(input_experience) + 18:
        validation_errors.append("⚠️  Age seems too low for the given experience years.")
    if input_working_hours < 35:
        validation_errors.append("⚠️  Working hours below standard threshold (35 hrs/week).")

    # ── Buttons ───────────────────────────────────────────────────────────────
    btn1, btn2, btn3 = st.columns([2, 1, 1])

    with btn1:
        predict_clicked = st.button(
            "🔮  Predict Salary", type="primary", use_container_width=True
        )
    with btn2:
        reset_clicked = st.button("🔄  Reset", use_container_width=True)
    with btn3:
        insights_shortcut = st.button("📊  View Insights", use_container_width=True)

    if reset_clicked:
        st.rerun()

    if insights_shortcut:
        st.info("Switch to **📊 Employee Insights** in the sidebar to explore workforce data.")

    # ── Prediction Logic ──────────────────────────────────────────────────────
    if predict_clicked:
        if validation_errors:
            for err in validation_errors:
                st.warning(err)

        try:
            enc_education  = label_encoders["Education_Level"].transform([input_education])[0]
            enc_department = label_encoders["Department"].transform([input_department])[0]
            enc_job_title  = label_encoders["Job_Title"].transform([input_job_title])[0]

            prediction_input = pd.DataFrame([[
                input_experience,
                enc_education,
                enc_department,
                enc_job_title,
                input_age,
                input_working_hours,
                input_performance,
            ]], columns=[
                "Experience_Years",
                "Education_Level",
                "Department",
                "Job_Title",
                "Age",
                "Working_Hours_Per_Week",
                "Performance_Score",
            ])

            predicted_salary = analytics_model.predict(prediction_input)[0]

            # Income Level classification
            if predicted_salary < 60000:
                income_level = "Entry Level"
                badge_class  = "badge-entry"
                income_icon  = "🔵"
            elif predicted_salary < 100000:
                income_level = "Mid Level"
                badge_class  = "badge-mid"
                income_icon  = "🟢"
            elif predicted_salary < 160000:
                income_level = "Senior Level"
                badge_class  = "badge-senior"
                income_icon  = "🟡"
            else:
                income_level = "Executive Level"
                badge_class  = "badge-executive"
                income_icon  = "🔴"

            # Performance Status
            if input_performance >= 4.5:
                perf_status = "🏆 Outstanding"
            elif input_performance >= 3.5:
                perf_status = "✅ Good"
            elif input_performance >= 2.5:
                perf_status = "⚠️ Average"
            else:
                perf_status = "❌ Needs Improvement"

            # ── Results Display ────────────────────────────────────────────────
            st.success("✅ Prediction generated successfully!")

            st.markdown(
                f"""<div class="salary-result">
                    <h1>💰 ${predicted_salary:,.2f}</h1>
                    <p>Estimated Annual Salary (USD)</p>
                </div>""",
                unsafe_allow_html=True,
            )

            r1, r2, r3 = st.columns(3)
            with r1:
                st.markdown(
                    f"**{income_icon} Income Level**\n\n"
                    f'<span class="{badge_class}">{income_level}</span>',
                    unsafe_allow_html=True,
                )
            with r2:
                st.markdown(f"**📈 Performance Status**\n\n{perf_status}")
            with r3:
                monthly = predicted_salary / 12
                st.markdown(f"**📅 Monthly Estimate**\n\n${monthly:,.2f} / month")

            # Summary breakdown
            with st.expander("📋 Prediction Summary"):
                summary_data = {
                    "Parameter"       : ["Experience", "Age", "Education", "Department",
                                         "Job Title", "Working Hours", "Performance"],
                    "Entered Value"   : [f"{input_experience} yrs", str(input_age),
                                         input_education, input_department,
                                         input_job_title, f"{input_working_hours} hrs/wk",
                                         f"{input_performance}/5.0"],
                }
                st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)

        except Exception as exc:
            st.error(f"❌ Prediction failed: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  VIEW 2 — EMPLOYEE INSIGHTS
# ══════════════════════════════════════════════════════════════════════════════
elif "📊 Employee Insights" in dashboard_view:
    st.markdown("---")
    st.markdown("## 📊 Employee Workforce Insights")

    if workforce_df is None:
        st.warning("⚠️  Dataset file not found. Place `employee_salary_dataset.xlsx` in this folder.")
        st.stop()

    insights_tab1, insights_tab2, insights_tab3 = st.tabs([
        "🏢 Department Analysis",
        "🎓 Education Analysis",
        "📋 Raw Data",
    ])

    with insights_tab1:
        st.markdown("### Average Salary by Department")
        dept_summary = (
            workforce_df.groupby("Department")["Salary"]
            .agg(["mean", "min", "max", "count"])
            .rename(columns={"mean": "Avg Salary", "min": "Min", "max": "Max", "count": "Headcount"})
            .sort_values("Avg Salary", ascending=False)
            .reset_index()
        )
        dept_summary["Avg Salary"] = dept_summary["Avg Salary"].map("${:,.0f}".format)
        dept_summary["Min"]        = dept_summary["Min"].map("${:,.0f}".format)
        dept_summary["Max"]        = dept_summary["Max"].map("${:,.0f}".format)
        st.dataframe(dept_summary, use_container_width=True, hide_index=True)

        st.markdown("### Salary Distribution by Department")
        dept_avg = workforce_df.groupby("Department")["Salary"].mean().sort_values()
        st.bar_chart(dept_avg)

    with insights_tab2:
        st.markdown("### Salary by Education Level")
        edu_summary = (
            workforce_df.groupby("Education_Level")["Salary"]
            .agg(["mean", "count"])
            .rename(columns={"mean": "Avg Salary", "count": "Employees"})
            .reset_index()
        )
        st.dataframe(edu_summary, use_container_width=True, hide_index=True)

        st.markdown("### Experience vs Salary")
        chart_df = workforce_df[["Experience_Years", "Salary"]].sort_values("Experience_Years")
        st.line_chart(chart_df.set_index("Experience_Years"))

    with insights_tab3:
        st.markdown("### Full Employee Dataset")
        st.dataframe(
            workforce_df.drop(columns=["Employee_ID"], errors="ignore"),
            use_container_width=True,
            hide_index=True,
        )
        st.info(f"📌 Showing {len(workforce_df)} employee records")


# ─── Footer ───────────────────────────────────────────────────────────────────
st.markdown(
    """<div class="footer">
        📊 Employee Salary Analytics Dashboard &nbsp;|&nbsp;
        Built with Streamlit &amp; Scikit-learn &nbsp;|&nbsp;
        © 2026 Divya &nbsp;|&nbsp;
        Powered by RandomForest ML
    </div>""",
    unsafe_allow_html=True,
)
