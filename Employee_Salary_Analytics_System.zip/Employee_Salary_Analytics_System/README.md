# 📊 Employee Salary Analytics System

> A machine-learning powered web application that predicts employee compensation
> based on professional attributes and provides interactive workforce insights.

---

## 🚀 Project Overview

The **Employee Salary Analytics System** uses a **Random Forest Regressor** trained
on 280 employee records to predict annual salaries. A modern **Streamlit** dashboard
provides two views:

1. **Salary Predictor** — Enter employee details and get an instant salary estimate
2. **Employee Insights** — Explore workforce trends by department and education level

---

## 📁 Folder Structure

```
Employee_Salary_Analytics_System/
│
├── app.py                          # Streamlit web dashboard
├── train_model.py                  # ML training pipeline
├── employee_salary_dataset.xlsx    # Training dataset (280 records)
├── salary_prediction_model.pkl     # Trained model (generated)
├── salary_encoders.pkl             # Label encoders (generated)
├── requirements.txt                # Python dependencies
├── README.md                       # This file
├── execution_steps.txt             # Quick execution guide
└── execution_video_flow.txt        # Screen-recording walkthrough guide
```

---

## ⚙️ Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Step 1 — Clone / Extract the project
```bash
cd Employee_Salary_Analytics_System
```

### Step 2 — Install dependencies
```bash
pip install -r requirements.txt
```

---

## 🏋️ Training the Model

Run the training pipeline to generate the model and encoder files:

```bash
python train_model.py
```

### What happens:
| Step | Action |
|------|--------|
| 1 | Load `employee_salary_dataset.xlsx` |
| 2 | Cleanse missing values (median/mode imputation) |
| 3 | Label-encode categorical columns |
| 4 | 80/20 train-holdout split |
| 5 | Train RandomForestRegressor (250 trees) |
| 6 | Evaluate — print R², MAE, RMSE, CV scores |
| 7 | Save `salary_prediction_model.pkl` + `salary_encoders.pkl` |

### Expected output:
```
══════════════════════════════════════════════════════
       EMPLOYEE SALARY ANALYTICS — MODEL REPORT
══════════════════════════════════════════════════════
  Training R²       : 0.9821
  Holdout R²        : 0.9654
  Model Accuracy    : 96.54 %
  MAE  (USD)        : $4,821.33
  RMSE (USD)        : $6,104.87
  CV R² (5-fold)    : 0.9601 ± 0.0124
══════════════════════════════════════════════════════

🎉  Training pipeline completed successfully!
```

---

## ▶️ Running the App

```bash
streamlit run app.py
```

Open your browser at: **http://localhost:8501**

---

## 🖥️ Application Features

### Salary Predictor
| Input Field | Type | Range |
|-------------|------|-------|
| Experience Years | Number | 0 – 40 |
| Age | Number | 18 – 65 |
| Education Level | Dropdown | Bachelor / Master / PhD |
| Department | Dropdown | 7 departments |
| Job Title | Dropdown | 10 titles |
| Working Hours/Week | Slider | 30 – 70 |
| Performance Score | Slider | 1.0 – 5.0 |

### Output
- 💰 **Predicted Salary** (USD)
- 🏷️ **Income Level** (Entry / Mid / Senior / Executive)
- ⭐ **Performance Status**
- 📅 **Monthly Estimate**

### Employee Insights
- Department salary analysis table
- Salary bar chart by department
- Education level comparison
- Experience vs Salary trend line
- Full dataset viewer

---

## 📸 Screenshots Section

> Add screenshots here after launching the application.

| Screen | Description |
|--------|-------------|
| `screenshot_predictor.png` | Salary prediction form |
| `screenshot_result.png` | Prediction result card |
| `screenshot_insights.png` | Employee insights dashboard |

---

## 🔮 Future Improvements

1. **Location-based adjustment** — Factor in city/region cost-of-living multipliers
2. **Salary range output** — Show confidence interval (min–max) instead of a point estimate
3. **SHAP explainability** — Visualise feature contributions per prediction
4. **Real-time retraining** — Allow CSV upload to retrain model in-browser
5. **Export to PDF** — Download prediction report as a formatted PDF
6. **Authentication** — Role-based login for HR team access
7. **REST API** — FastAPI backend for integration with HR systems
8. **Benchmarking** — Compare employee salary vs industry percentile

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|------------|
| Language | Python 3.11 |
| Web Framework | Streamlit |
| ML Library | Scikit-learn |
| Algorithm | Random Forest Regressor |
| Data | Pandas, NumPy |
| Excel I/O | OpenPyXL |
| Model Storage | Joblib |

---

## 👩‍💻 Author

**Divya** — May 2026

---

*Employee Salary Analytics System — Powered by Machine Learning*
